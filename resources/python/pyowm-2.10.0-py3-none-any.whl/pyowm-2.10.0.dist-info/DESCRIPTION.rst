PyOWM is a client Python wrapper library for OpenWeatherMap web APIs. It allows quick and easy 
consumption of OWM data from Python applications via a simple object model and in a human-friendly fashion.

