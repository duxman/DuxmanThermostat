ROOT_STATIONS_API_XMLNS_URL = 'http://github.com/csparpa/pyowm/tree/master/pyowm/stationsapi30/xsd'

# XMLNS Prefixes
STATION_XMLNS_PREFIX = 's'


# XMLNS URLs
STATION_XMLNS_URL = ROOT_STATIONS_API_XMLNS_URL + '/station.xsd'
